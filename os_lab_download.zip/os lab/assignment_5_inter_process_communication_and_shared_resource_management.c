#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/wait.h>

#define SHM_SIZE 1024

int main() {
    key_t key = ftok("shmfile", 65);
    int shmid = shmget(key, SHM_SIZE, 0666 | IPC_CREAT);

    if (fork() == 0) {  // Child Process (Writer)
        char *str = (char*) shmat(shmid, (void*)0, 0);
        strcpy(str, "Shared Memory IPC Payload Data");
        printf("[Child] Data written to shared memory: %s\n", str);
        shmdt(str);
        exit(0);
    } else {            // Parent Process (Reader)
        wait(NULL);
        char *str = (char*) shmat(shmid, (void*)0, 0);
        printf("[Parent] Data read from shared memory: %s\n", str);
        shmdt(str);
        shmctl(shmid, IPC_RMID, NULL);  // Cleanup Shared Memory
    }
    return 0;
}