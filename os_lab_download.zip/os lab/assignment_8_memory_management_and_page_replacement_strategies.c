#include <stdio.h>

int find_lru(int time[], int n) {
    int minimum = time[0], pos = 0;
    for (int i = 1; i < n; ++i) {
        if (time[i] < minimum) {
            minimum = time[i];
            pos = i;
        }
    }
    return pos;
}

int main() {
    int frames_cnt = 3;
    int pages[] = {7, 0, 1, 2, 0, 3, 0, 4, 2, 3};
    int n = sizeof(pages) / sizeof(pages[0]);
    int frames[3], time[3], faults = 0, counter = 0;

    for (int i = 0; i < frames_cnt; ++i) frames[i] = -1;

    for (int i = 0; i < n; ++i) {
        int flag1 = 0, flag2 = 0;

        // Check for a hit
        for (int j = 0; j < frames_cnt; ++j) {
            if (frames[j] == pages[i]) {
                counter++;
                time[j] = counter;
                flag1 = flag2 = 1;
                break;
            }
        }

        // Miss: use an empty frame if available
        if (flag1 == 0) {
            for (int j = 0; j < frames_cnt; ++j) {
                if (frames[j] == -1) {
                    counter++;
                    faults++;
                    frames[j] = pages[i];
                    time[j] = counter;
                    flag2 = 1;
                    break;
                }
            }
        }

        // Miss and all frames full: replace the least recently used page
        if (flag2 == 0) {
            int pos = find_lru(time, frames_cnt);
            counter++;
            faults++;
            frames[pos] = pages[i];
            time[pos] = counter;
        }
    }

    printf("Total LRU Page Faults: %d (Fault Rate: %.2f%%)\n", faults, ((float)faults / n) * 100);
    return 0;
}