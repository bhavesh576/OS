#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main() {
    int req[] = {98, 183, 37, 122, 14, 124, 65, 67};
    int n = sizeof(req) / sizeof(req[0]);
    int head = 53;
    bool visited[8] = {false};
    int total_head_movement = 0;

    printf("Head Movement Traversal Order:\n%d", head);

    for (int i = 0; i < n; i++) {
        int min_dist = 1e9, index = -1;

        for (int j = 0; j < n; j++) {
            if (!visited[j]) {
                int dist = abs(req[j] - head);
                if (dist < min_dist) {
                    min_dist = dist;
                    index = j;
                }
            }
        }

        visited[index] = true;
        total_head_movement += min_dist;
        head = req[index];
        printf(" -> %d", head);
    }

    printf("\nTotal Head Seek Movement (SSTF): %d tracks\n", total_head_movement);
    return 0;
}