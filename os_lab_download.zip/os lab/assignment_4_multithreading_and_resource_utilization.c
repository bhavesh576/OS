#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

#define SIZE 10000000
#define NUM_THREADS 4

int array[SIZE];
long long partial_sums[NUM_THREADS];

void* sum_worker(void* arg) {
    long thread_id = (long)arg;
    int chunk_size = SIZE / NUM_THREADS;
    int start = thread_id * chunk_size;
    int end = (thread_id == NUM_THREADS - 1) ? SIZE : start + chunk_size;

    long long sum = 0;
    for (int i = start; i < end; i++) {
        sum += array[i];
    }
    partial_sums[thread_id] = sum;
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < SIZE; i++) array[i] = 1;

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (long i = 0; i < NUM_THREADS; i++) {
        pthread_create(&threads[i], NULL, sum_worker, (void*)i);
    }

    long long total_sum = 0;
    for (int i = 0; i < NUM_THREADS; i++) {
        pthread_join(threads[i], NULL);
        total_sum += partial_sums[i];
    }

    clock_gettime(CLOCK_MONOTONIC, &end);

    double elapsed = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    printf("Total Sum: %lld | Execution Time (%d threads): %.4f seconds\n",
           total_sum, NUM_THREADS, elapsed);

    return 0;
}