#include <stdio.h>
#include <stdbool.h>

#define P 5 // Processes
#define R 3 // Resource Types

int main() {
    int alloc[P][R] = {{0, 1, 0}, {2, 0, 0}, {3, 0, 2}, {2, 1, 1}, {0, 0, 2}};
    int max[P][R]   = {{7, 5, 3}, {3, 2, 2}, {9, 0, 2}, {2, 2, 2}, {4, 3, 3}};
    int avail[R]    = {3, 3, 2};
    int need[P][R];

    for (int i = 0; i < P; i++)
        for (int j = 0; j < R; j++)
            need[i][j] = max[i][j] - alloc[i][j];

    bool finished[P] = {false};
    int safe_seq[P];
    int count = 0;

    while (count < P) {
        bool found = false;
        for (int i = 0; i < P; i++) {
            if (!finished[i]) {
                int j;
                for (j = 0; j < R; j++)
                    if (need[i][j] > avail[j]) break;

                if (j == R) { // Process i can execute
                    for (int k = 0; k < R; k++) avail[k] += alloc[i][k];
                    safe_seq[count++] = i;
                    finished[i] = true;
                    found = true;
                }
            }
        }
        if (!found) {
            printf("System is in an UNSAFE State! Deadlock possible.\n");
            return 0;
        }
    }

    printf("System is in a SAFE State.\nSafe Sequence: ");
    for (int i = 0; i < P; i++) printf("P%d ", safe_seq[i]);
    printf("\n");
    return 0;
}