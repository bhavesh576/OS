import time
import math

print("--- AI Workload Execution Engine Started ---")
start_time = time.time()

# Simulating CPU-intensive ML task
data = [math.sin(i) * math.cos(i) for i in range(1, 5000000)]

print(f"Inference simulation completed successfully in {time.time() - start_time:.3f} seconds.")