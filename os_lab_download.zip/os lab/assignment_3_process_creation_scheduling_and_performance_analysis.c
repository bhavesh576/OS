#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

typedef struct {
    int pid, burst_time, wait_time, tat_time;
} Process;

void calculate_fcfs(Process p[], int n) {
    p[0].wait_time = 0;
    p[0].tat_time = p[0].burst_time;

    for (int i = 1; i < n; i++) {
        p[i].wait_time = p[i-1].wait_time + p[i-1].burst_time;
        p[i].tat_time = p[i].wait_time + p[i].burst_time;
    }

    float total_wt = 0, total_tat = 0;
    printf("\nPID\tBurst\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        total_wt += p[i].wait_time;
        total_tat += p[i].tat_time;
        printf("%d\t%d\t%d\t%d\n", p[i].pid, p[i].burst_time, p[i].wait_time, p[i].tat_time);
    }
    printf("Avg WT: %.2f | Avg TAT: %.2f\n", total_wt / n, total_tat / n);
}

int main() {
    pid_t pid = fork();

    if (pid < 0) {
        perror("Fork Failed");
        return 1;
    } else if (pid == 0) {
        printf("[Child Process] PID: %d (Parent PID: %d)\n", getpid(), getppid());
        exit(0);
    } else {
        wait(NULL);
        printf("[Parent Process] Child Finished. Running FCFS Simulation...\n");
        Process proc[] = {{1, 6, 0, 0}, {2, 8, 0, 0}, {3, 3, 0, 0}};
        calculate_fcfs(proc, 3);
    }
    return 0;
}