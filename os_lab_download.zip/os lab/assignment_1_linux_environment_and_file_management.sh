#!/bin/bash
# Module 1 Demonstration Script
# 1. Directory and File Operations
mkdir -p os_lab/module1 && cd os_lab/module1
touch sample.txt
echo "Operating Systems Lab - AI & ML" > sample.txt
# 2. Permission and Ownership Management
chmod 644 sample.txt
ls -l sample.txt
# 3. Process Monitoring and Signal Control
sleep 100 &
PID=$!
echo "Background Process Started with PID: $PID"
ps -p $PID
kill -9 $PID
echo "Process $PID terminated."